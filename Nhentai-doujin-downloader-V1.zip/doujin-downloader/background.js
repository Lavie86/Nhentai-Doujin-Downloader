// Import JSZip for service worker
importScripts('jszip.min.js');

// Helper: Sanitize filename for downloads
function sanitizeFilename(filename) {
  return filename
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, '') // Remove invalid characters
    .replace(/^\.+/, '') // Remove leading dots
    .replace(/\.+$/, '') // Remove trailing dots
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim()
    .substring(0, 100) // Limit length
    || 'download'; // Fallback name
}

async function convertToPng(blob) {
  // Use OffscreenCanvas instead of DOM canvas
  const imgBitmap = await createImageBitmap(blob);

  const canvas = new OffscreenCanvas(imgBitmap.width, imgBitmap.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(imgBitmap, 0, 0);

  // Default converts to PNG
  return canvas.convertToBlob({ type: 'image/png' });
}

// Safe message sending (won't throw if popup is closed)
function safeMessage(message) {
  chrome.runtime.sendMessage(message).catch(() => {
    // Popup is closed, ignore silently
  });
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startDownload") {
    handleDownload(message.data);
    sendResponse({ success: true });
  }
});

let safeTitle = 'Nhentai_Doujin'

async function handleDownload({ title, galleryId, totalPages, imageFormat }) {
  try {
    const zip = new JSZip();
    let successCount = 0;
    let errorCount = 0;
    safeTitle = sanitizeFilename(title);
    let formats = ['jpg', 'webp', 'png', 'gif'];
    
    const index = formats.indexOf(imageFormat);
    if (index > -1) { 
      formats.splice(index, 1); 
    }

    for (let i = 1; i <= totalPages; i++) {
      try {
        const host = `https://i${(i % 3) + 1}.nhentai.net`; // rotate hosts
        let url = `${host}/galleries/${galleryId}/${i}.${imageFormat}`;

        console.log('Fetching: ' + url);
        let correctFormat = true;

        let response = await fetch(url);
        if (!response.ok) {
          correctFormat = false;
          let counter = 0
          while(!correctFormat) {
            url = `${host}/galleries/${galleryId}/${i}.${formats[counter]}`;
            console.log('Format finder fethcing: ' + url);
            response = await fetch(url);
            if(response.ok) {
              correctFormat = true;
              console.log('Format finder resolved image type: ' + formats[counter]);
            }
            await new Promise(r => setTimeout(r, 500 + Math.random() * 500));
            counter++;
          }
        }
      if(!correctFormat) {
        console.error(`Not correct image format for page: ${i}`);
      }
      let blob = await response.blob();

        // Convert ANY supported image format → PNG
      if(imageFormat) {
          // If it's already PNG, just keep it
          if (imageFormat !== 'png') {
              blob = await convertToPng(blob, imageFormat);
          }
      }

        // Add to zip
        zip.file(`page_${String(i).padStart(3, "0")}.png`, blob);
        successCount++;

        // Update progress in popup (if open)
        const percent = Math.round((i / totalPages) * 100);
        safeMessage({
          action: "updateProgress",
          current: i,
          total: totalPages,
          percent: percent
        });

        // Random delay to avoid bot detection
        await new Promise(r => setTimeout(r, 500 + Math.random() * 500));

      } catch (err) {
        console.error(`Failed to fetch page ${i}:`, err);
        errorCount++;
      }
    }

    if (successCount === 0) {
      throw new Error("No pages downloaded successfully");
    }

    // Generate zip as base64 data URL (works in service workers)
    const content = await zip.generateAsync({ 
      type: "base64",
      compression: "DEFLATE",
      compressionOptions: { level: 6 }
    });
    
    // Create data URL for download
    const dataUrl = `data:application/zip;base64,${content}`;
    
    // Download using Chrome Downloads API
    chrome.downloads.download({
      url: dataUrl,
      filename: `${safeTitle}.zip`,
      saveAs: false
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("Download failed:", chrome.runtime.lastError.message);
        safeMessage({ action: "downloadError" });
      } else {
        console.log(`Download started with ID: ${downloadId}`);
        safeMessage({ action: "downloadComplete" });
      }
    });

  } catch (err) {
    console.error("Download process failed:", err);
    currentDownload = null; // Clear download state
    safeMessage({ action: "downloadError" });
  }
}