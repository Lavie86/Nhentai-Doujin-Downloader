HOW TO ADD EXTENSION:

go to chrome://extensions/

turn on developer mode

select load unpacked

select the folder this textfile is inside