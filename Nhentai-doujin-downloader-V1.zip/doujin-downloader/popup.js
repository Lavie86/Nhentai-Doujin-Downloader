// --- Helper: Convert WebP → PNG (moved to background) ---
// This will be handled in background script

// --- Detect doujin info & cover when popup opens ---
window.addEventListener("DOMContentLoaded", async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  // Skip chrome:// or extension pages
  if (!tab.url.startsWith("http")) {
    document.getElementById("doujin_title_content").textContent = "none";
    document.getElementById("info-text").style.display = "block";
    return;
  }

  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      try {
        // Grab all three parts of the title
        const beforeEl = document.querySelector(".before");
        const prettyEl = document.querySelector(".pretty");
        const afterEl = document.querySelector(".after");

        const titleParts = [];
        if (beforeEl) titleParts.push(beforeEl.textContent.trim());
        if (prettyEl) titleParts.push(prettyEl.textContent.trim());
        if (afterEl) titleParts.push(afterEl.textContent.trim());

        const title = titleParts.join(" ").replace(/[<>:"/\\|?*]+/g, "") || null;

        // Gallery ID
        const lazy = document.querySelector(".lazyload");
        let src = lazy ? (lazy.getAttribute("data-src") || lazy.getAttribute("src")) : null;
        let galleryId = null;
        if (src) {
          if (src.startsWith("//")) src = "https:" + src;
          const match = src.match(/galleries\/(\d+)/);
          if (match) galleryId = match[1];
        }

        // Total pages
        const thumbsWrapper = document.querySelector(".thumbs");
        const totalPages = thumbsWrapper ? thumbsWrapper.querySelectorAll(".thumb-container").length : 0;

        return { title, galleryId, coverUrl: src, totalPages };
      } catch {
        return { title: null, galleryId: null, coverUrl: null, totalPages: 0 };
      }
    }
  });

  const { title, galleryId, coverUrl } = results[0].result;
  const titleSpan = document.getElementById("doujin_title_content");
  const coverEl = document.getElementById("cover");
  const infoEl = document.getElementById("info-text");
  const downloadBtn = document.getElementById("download");
  const progress = document.querySelector(".progress");
  const progressText = document.getElementById("progress-text");

  if (title && galleryId) {
    // Doujin detected
    titleSpan.textContent = title; 
    if (coverUrl) {
      coverEl.src = coverUrl.startsWith("//") ? "https:" + coverUrl : coverUrl;
      coverEl.style.display = "block";
    }
    infoEl.style.display = "none";
    downloadBtn.style.display = "block";
    progress.style.display = "block";
    progressText.style.display = "block";
  } else {
    // No doujin detected
    titleSpan.textContent = "none";
    coverEl.style.display = "none";
    infoEl.style.display = "block";
    downloadBtn.style.display = "none";
    progress.style.display = "none";
    progressText.style.display = "none";
  }

  // Listen for progress updates from background script
  const messageListener = (message, sender, sendResponse) => {
    if (message.action === "updateProgress") {
      const progressBar = document.getElementById("progress-bar");
      const progressText = document.getElementById("progress-text");
      
      progressBar.style.width = `${message.percent}%`;
      progressText.textContent = `Downloading ${message.current} of ${message.total} (${message.percent}%)`;
    } else if (message.action === "downloadComplete") {
      const progressText = document.getElementById("progress-text");
      progressText.textContent = "Download complete!";
      
      // Reset after a few seconds
      setTimeout(() => {
        progressText.textContent = "Ready...";
        document.getElementById("progress-bar").style.width = "0%";
      }, 3000);
    } else if (message.action === "downloadError") {
      alert("An error occurred while downloading the doujin.");
      document.getElementById("progress-text").textContent = "Ready...";
      document.getElementById("progress-bar").style.width = "0%";
    }
    
    // Always send response to prevent "receiving end does not exist" errors
    sendResponse({ received: true });
  };
  
  chrome.runtime.onMessage.addListener(messageListener);
  
  // Clean up listener when popup closes
  window.addEventListener('beforeunload', () => {
    chrome.runtime.onMessage.removeListener(messageListener);
  });
});

document.getElementById("download").addEventListener("click", async () => {
  try {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error("No active tab found");

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const beforeEl = document.querySelector(".before");
        const prettyEl = document.querySelector(".pretty");
        const afterEl = document.querySelector(".after");

        const titleParts = [];
        if (beforeEl) titleParts.push(beforeEl.textContent.trim());
        if (prettyEl) titleParts.push(prettyEl.textContent.trim());
        if (afterEl) titleParts.push(afterEl.textContent.trim());

        const title = titleParts.join(" ").replace(/[<>:"/\\|?*\x00-\x1f]+/g, "").trim() || "unknown_doujin";

        const lazy = document.querySelector(".lazyload");
        let src = lazy ? (lazy.getAttribute("data-src") || lazy.getAttribute("src")) : null;
        let galleryId = null;
        if (src) {
          if (src.startsWith("//")) src = "https:" + src;
          const match = src.match(/galleries\/(\d+)/);
          if (match) galleryId = match[1];
        }

        let imageFormat = '';
        if (src) {
          const match = src.match(/\.(jpe?g|png|gif|bmp|webp|svg|tiff)(?=$|\?)/i);

          imageFormat = match ? match[1].toLowerCase() : null;
        }

        const thumbsWrapper = document.querySelector(".thumbs");
        const totalPages = thumbsWrapper ? thumbsWrapper.querySelectorAll(".thumb-container").length : 0;

        return { title, galleryId, totalPages, imageFormat };
      }
    });

    const { title, galleryId, totalPages, imageFormat } = results[0].result;
    if (!galleryId || totalPages === 0) {
      alert("Could not detect doujin properly!");
      return;
    }

    // Send download request to background script
    chrome.runtime.sendMessage({
      action: "startDownload",
      data: { title, galleryId, totalPages, imageFormat }
    });

    // Update UI to show download started
    document.getElementById("progress-text").textContent = "Starting download...";
    
  } catch (err) {
    console.error("Download failed:", err);
    alert("An error occurred while starting the download.");
  }
});